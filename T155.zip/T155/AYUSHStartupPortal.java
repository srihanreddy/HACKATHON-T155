import java.util.*;

class User {
    String username;
    String password;
    String role;

    User(String username, String password, String role) {
        this.username = username;
        this.password = password;
        this.role = role;
    }
}

class RegistrationPortal {
    private List<User> users = new ArrayList<>();
    private Map<String, String> applications = new HashMap<>();
    private Map<String, String> documents = new HashMap<>();
    private Map<String, String> applicationStatus = new HashMap<>();

    public void registerUser(String username, String password, String role) {
        users.add(new User(username, password, role));
        System.out.println("User registered successfully!");
    }

    public boolean loginUser(String username, String password) {
        for (User user : users) {
            if (user.username.equals(username) && user.password.equals(password)) {
                System.out.println("Login successful!");
                return true;
            }
        }
        System.out.println("Invalid credentials.");
        return false;
    }

    public void submitApplication(String username, String applicationData) {
        applications.put(username, applicationData);
        applicationStatus.put(username, "Pending");
        System.out.println("Application submitted successfully!");
    }

    public void uploadDocument(String username, String document) {
        documents.put(username, document);
        System.out.println("Document uploaded successfully!");
    }

    public void checkStatus(String username) {
        String status = applicationStatus.getOrDefault(username, "No application found.");
        System.out.println("Application Status: " + status);
    }

    public void updateStatus(String username, String status) {
        if (applicationStatus.containsKey(username)) {
            applicationStatus.put(username, status);
            System.out.println("Application status updated to: " + status);
        } else {
            System.out.println("No application found for this user.");
        }
    }

    public void supportAndResources() {
        System.out.println("For support, contact support@ayushportal.com.");
        System.out.println("Visit our resources section for guidelines and help articles.");
    }
}

public class AYUSHStartupPortal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RegistrationPortal portal = new RegistrationPortal();

        System.out.println("Welcome to the AYUSH Startup Registration Portal");
        
        while (true) {
            System.out.println("1. Register\n2. Login\n3. Submit Application\n4. Upload Document\n5. Check Status\n6. Update Status (Admin)\n7. Support & Resources\n8. Exit");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter username: ");
                    String username = scanner.nextLine();
                    System.out.print("Enter password: ");
                    String password = scanner.nextLine();
                    System.out.print("Enter role (User/Admin): ");
                    String role = scanner.nextLine();
                    portal.registerUser(username, password, role);
                    break;
                case 2:
                    System.out.print("Enter username: ");
                    String loginUser = scanner.nextLine();
                    System.out.print("Enter password: ");
                    String loginPass = scanner.nextLine();
                    portal.loginUser(loginUser, loginPass);
                    break;
                case 3:
                    System.out.print("Enter username: ");
                    String appUser = scanner.nextLine();
                    System.out.print("Enter application details: ");
                    String applicationData = scanner.nextLine();
                    portal.submitApplication(appUser, applicationData);
                    break;
                case 4:
                    System.out.print("Enter username: ");
                    String docUser = scanner.nextLine();
                    System.out.print("Enter document name: ");
                    String document = scanner.nextLine();
                    portal.uploadDocument(docUser, document);
                    break;
                case 5:
                    System.out.print("Enter username: ");
                    String statusUser = scanner.nextLine();
                    portal.checkStatus(statusUser);
                    break;
                case 6:
                    System.out.print("Enter username: ");
                    String updateUser = scanner.nextLine();
                    System.out.print("Enter new status: ");
                    String status = scanner.nextLine();
                    portal.updateStatus(updateUser, status);
                    break;
                case 7:
                    portal.supportAndResources();
                    break;
                case 8:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option, please try again.");
            }
        }
    }
}